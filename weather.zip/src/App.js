import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [weatherData, setWeatherData] = useState(null);    // Current weather data
  const [forecastData, setForecastData] = useState([]);    // Forecast data
  const [loading, setLoading] = useState(true);            // Loading state
  const [error, setError] = useState(null);                // Error handling
  const [unit, setUnit] = useState('C');                   // Temperature unit state (°C or °F)
  const [selectedDay, setSelectedDay] = useState(null);    // State for selected day
  const [location, setLocation] = useState('53.1,-0.13');  // Default location

  // Fetch weather data from the API
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await axios.get('https://weatherapi-com.p.rapidapi.com/forecast.json', {
          params: { q: location, days: 7 },
          headers: {
            'x-rapidapi-key': '89b471f5demsh2b0a892b7887145p1f0d8fjsn53e553a86ec5',
            'x-rapidapi-host': 'weatherapi-com.p.rapidapi.com',
          },
        });

        const data = response.data;
        if (data.current && data.forecast) {
          setWeatherData(data.current);                    // Set current weather data
          setForecastData(data.forecast.forecastday);      // Set 7-day forecast data
          setSelectedDay(data.forecast.forecastday[0]);    // Default to the first day in the forecast
        } else {
          throw new Error('Data format error: Missing current or forecast data');
        }

        setLoading(false); // Loading done
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchWeather();
  }, [location]);

  // Toggle between Celsius and Fahrenheit
  const toggleTempUnit = () => {
    setUnit((prevUnit) => (prevUnit === 'C' ? 'F' : 'C'));
  };

  // Helper function to get temperature in the desired unit
  const getTemperature = (tempC) => {
    return unit === 'C' ? tempC : (tempC * 9) / 5 + 32;
  };

  // Handle loading and error states
  if (loading) {
    return <div>Loading weather data...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="weather-app">
      <div className="container">
        {/* Current weather section */}
        {weatherData && (
          <header className="current-weather d-flex justify-content-between align-items-center pt-3">
            <span className="temperature">{getTemperature(weatherData.temp_c).toFixed(1)}°{unit}</span>
            <div>
              <h5 className="location">Current Location</h5>
              <p className="cloudy">{weatherData.condition.text} / {weatherData.wind_mph} mph</p>
            </div>
            <span className="toggle" onClick={toggleTempUnit}>°F | °C</span>
          </header>
        )}

        {/* Background Image */}
        <div className="background-image">
          <img src="w.jpg" alt="background" className="w-100" />
        </div>

        {/* Selected Day Forecast Details */}
        {selectedDay && (
          <div className="selected-day mt-4">
            <h4>Selected Day: {new Date(selectedDay.date).toLocaleDateString()}</h4>
            <p>Avg Temp: {getTemperature(selectedDay.day.avgtemp_c).toFixed(1)}°{unit}</p>
            <p>Condition: {selectedDay.day.condition.text}</p>
          </div>
        )}

        {/* Weather Forecast Section */}
        <footer className="weather-forecast mt-4">
          <div className="row text-center">
            {forecastData.length > 0 ? (
              forecastData.map((day, index) => (
                <div 
                  key={index} 
                  className={`col forecast-day ${selectedDay && selectedDay.date === day.date ? 'active' : ''}`}
                  onClick={() => setSelectedDay(day)} // Add click handler for day selection
                >
                  <p>{new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}</p>
                  <span>{getTemperature(day.day.avgtemp_c).toFixed(1)}°</span>
                </div>
              ))
            ) : (
              <p>No forecast data available.</p>
            )}
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;

import React, { useState } from 'react';
import './Login.css'; // Reusing the same CSS file for consistent design

const API_URL = 'https://api.jsonbin.io/v3/b/66edbba5acd3cb34a8882c91'; // User credentials bin
const MASTER_KEY = '$2a$10$Iv/FI7qXcS0nVxaXMQqb0ebBEM/KPvbUR2ZN4yDWKH3JQKj0UFjAS';

function Signup({ onSignup }) {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSignup = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validate form inputs
    if (!email || !username || !password) {
      setError('All fields are required');
      return;
    }

    // Fetch existing users to check for duplicate usernames
    const response = await fetch(API_URL, {
      method: 'GET',
      headers: {
        'X-Master-Key': MASTER_KEY,
      },
    });
    const data = await response.json();

    // Check if the username already exists
    const userExists = data.record.some(user => user.username === username);
    if (userExists) {
      setError('Username already exists');
      return;
    }

    // Create new user object in the correct order: email, password, username, userId
    const newUser = {
      email,
      password,
      username,
      userId: Date.now() // Using timestamp as a unique user ID
    };

    // Save the new user to the bin
    await fetch(API_URL, {
      method: 'PUT', // Use PUT to update the existing record
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': MASTER_KEY,
      },
      body: JSON.stringify({ record: [...data.record, newUser] }), // Append new user to existing records
    });

    setSuccess('Signup successful! You can now log in.');
    onSignup(newUser.userId); // Pass the new user ID if needed
  };

  return (
    <div className="background">
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-8 col-lg-6">
            <div className="card shadow-lg border-light">
              <div className="card-body">
                <h3 className="text-center mb-4">Sign Up</h3>
                {error && <div className="alert alert-danger">{error}</div>}
                {success && <div className="alert alert-success">{success}</div>}
                <form onSubmit={handleSignup}>
                  <div className="form-group mb-3">
                    <label htmlFor="email">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="form-control"
                      placeholder="Enter email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="username">Username</label>
                    <input
                      type="text"
                      id="username"
                      className="form-control"
                      placeholder="Enter username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="password">Password</label>
                    <input
                      type="password"
                      id="password"
                      className="form-control"
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary w-100">Sign Up</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;

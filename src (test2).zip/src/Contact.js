import React from 'react';

function Contact() {
  return (
    <div className="container text-center mt-5">
      <h1 className="display-4 mb-4">Contact Us</h1>
      <p className="lead mb-4">For more information, feel free to contact us.</p>
      <div className="row">
        <div className="col-md-4 mb-3">
          <h3>Email Us</h3>
          <p>Email: support@scotiabank.com</p>
        </div>
        <div className="col-md-4 mb-3">
          <h3>Talk to an Agent</h3>
          <p>Call us at: 1-800-123-4567</p>
        </div>
        <div className="col-md-4 mb-3">
          <h3>Book an Appointment</h3>
          <p>Schedule a visit: <a href="/appointment">Book Now</a></p>
        </div>
      </div>
    </div>
  );
}

export default Contact;

import React, { useState, useEffect } from 'react';
import './Transactions.css';

const API_URL = 'https://api.jsonbin.io/v3/b/66edcabaad19ca34f8a9bb4e'; // Transactions bin
const MASTER_KEY = '$2a$10$Iv/FI7qXcS0nVxaXMQqb0ebBEM/KPvbUR2ZN4yDWKH3JQKj0UFjAS';

const Transactions = ({ onLogout, userId }) => {
  const [amount, setAmount] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(0);
  const [recipientId, setRecipientId] = useState('');
  const [error, setError] = useState('');

  // Fetch transactions for the logged-in user
  const fetchTransactions = async () => {
    try {
      const response = await fetch(API_URL, {
        method: 'GET',
        headers: {
          'X-Master-Key': MASTER_KEY,
        },
      });
      if (!response.ok) {
        throw new Error('Failed to fetch transactions');
      }
      const data = await response.json();
      const userTransactions = data.record.filter(transaction => transaction.userId === userId);
      const initialBalance = userTransactions.reduce((acc, txn) => acc + txn.amount, 0);
      setTransactions(userTransactions);
      setBalance(initialBalance);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  // Save transactions to JSON bin
  const saveTransactions = async (updatedTransactions) => {
    try {
      const response = await fetch(API_URL, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': MASTER_KEY,
        },
        body: JSON.stringify({ record: updatedTransactions }),
      });
      if (!response.ok) {
        throw new Error('Failed to save transactions');
      }
    } catch (error) {
      console.error('Error saving transactions:', error);
    }
  };

  // Handle deposit action
  const handleDeposit = async (e) => {
    e.preventDefault();
    try {
      const amt = parseInt(amount);
      if (isNaN(amt) || amt <= 0) {
        setError('Please enter a valid amount');
        return;
      }

      const newTransaction = {
        userId,
        amount: amt,
        type: 'Deposit',
        balanceAfter: balance + amt,
      };

      const updatedTransactions = [...transactions, newTransaction];
      await saveTransactions(updatedTransactions);
      setTransactions(updatedTransactions);
      setBalance(balance + amt);
      setAmount('');
      setError('');
    } catch (error) {
      console.error('Error processing deposit:', error);
      setError('Failed to process deposit');
    }
  };

  // Handle withdraw action
  const handleWithdraw = async (e) => {
    e.preventDefault();
    try {
      const amt = parseInt(amount);
      if (isNaN(amt) || amt <= 0 || amt > balance) {
        setError('Please enter a valid amount');
        return;
      }

      const newTransaction = {
        userId,
        amount: -amt,
        type: 'Withdraw',
        balanceAfter: balance - amt,
      };

      const updatedTransactions = [...transactions, newTransaction];
      await saveTransactions(updatedTransactions);
      setTransactions(updatedTransactions);
      setBalance(balance - amt);
      setAmount('');
      setError('');
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      setError('Failed to process withdrawal');
    }
  };

  // Handle e-transfer action
  const handleETransfer = async (e) => {
    e.preventDefault();
    try {
      const amt = parseInt(amount);
      if (isNaN(amt) || amt <= 0 || amt > balance || !recipientId) {
        setError('Please enter a valid amount and recipient ID');
        return;
      }

      const newTransaction = {
        userId,
        amount: -amt,
        type: 'E-Transfer',
        recipientId,
        balanceAfter: balance - amt,
      };

      const updatedTransactions = [...transactions, newTransaction];
      await saveTransactions(updatedTransactions);
      setTransactions(updatedTransactions);
      setBalance(balance - amt);
      setAmount('');
      setRecipientId('');
      setError('');
    } catch (error) {
      console.error('Error processing e-transfer:', error);
      setError('Failed to process e-transfer');
    }
  };

  // Fetch transactions on component mount
  useEffect(() => {
    fetchTransactions();
  }, [userId]);

  return (
    <div className="container mt-5">
      <button className="btn btn-danger mb-3" onClick={onLogout}>Logout</button>

      {/* Deposit form */}
      <div className="card p-4">
        <h2>Deposit</h2>
        <form onSubmit={handleDeposit}>
          <div className="form-group mb-3">
            <label htmlFor="depositAmount">Amount</label>
            <input
              type="number"
              id="depositAmount"
              className="form-control"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">Deposit</button>
        </form>
      </div>

      {/* Withdraw form */}
      <div className="card p-4 mt-5">
        <h2>Withdraw</h2>
        <form onSubmit={handleWithdraw}>
          <div className="form-group mb-3">
            <label htmlFor="withdrawAmount">Amount</label>
            <input
              type="number"
              id="withdrawAmount"
              className="form-control"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">Withdraw</button>
        </form>
      </div>

      {/* E-Transfer form */}
      <div className="card p-4 mt-5">
        <h2>E-Transfer</h2>
        <form onSubmit={handleETransfer}>
          <div className="form-group mb-3">
            <label htmlFor="recipientId">Recipient ID</label>
            <input
              type="text"
              id="recipientId"
              className="form-control"
              placeholder="Enter recipient ID"
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              required
            />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="etransferAmount">Amount</label>
            <input
              type="number"
              id="etransferAmount"
              className="form-control"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">E-Transfer</button>
        </form>
      </div>

      {/* Error message */}
      {error && <div className="alert alert-danger mt-3">{error}</div>}

      {/* Transactions history */}
      <div className="mt-5">
        <h2>Transaction History</h2>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>User ID</th>
              <th>Amount</th>
              <th>Type</th>
              <th>Balance After Transaction</th>
              <th>Recipient ID</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>
                <td>{transaction.userId}</td>
                <td>{transaction.amount}</td>
                <td>{transaction.type}</td>
                <td>{transaction.balanceAfter}</td>
                <td>{transaction.recipientId || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Transactions;
